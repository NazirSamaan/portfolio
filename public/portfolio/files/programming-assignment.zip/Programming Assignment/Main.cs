﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Programming_Assignment
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void StudentButton_Click(object sender, EventArgs e) // Student Button //
        {
            Student F3 = new Student();
            F3.Show();
            this.Hide();
        }

        private void SubjectButton_Click(object sender, EventArgs e) // Subject Button
        {
            SubjectForm F4 = new SubjectForm();
            F4.Show();
            this.Hide();
        }

        private void Main_Load(object sender, EventArgs e)
        {

        }
    }
}
