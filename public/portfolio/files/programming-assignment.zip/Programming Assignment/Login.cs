﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Programming_Assignment
{
    public partial class Login : Form
    {
        OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\User\OneDrive\Desktop\Programming\assignmentdatabase.accdb");
        OleDbCommand cmd = new OleDbCommand();
        public Login()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, EventArgs e) // Login Button //
        {
            string user = Nametextbox.Text;
            string pword = Passwordtextbox.Text;

            con.Open();
            cmd.Connection = con;
            cmd.CommandText = "Select* FROM Login where Username ='" + user + "'AND Password ='" + pword + "'";
            OleDbDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                Main F2 = new Main();
                F2.Show();
                this.Hide();
            }

            else
            {
                MessageBox.Show("Your Username or Password is INCORRECT!");
            }
            con.Close();
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }
    }
}
