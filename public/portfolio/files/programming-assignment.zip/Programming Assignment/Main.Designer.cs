﻿namespace Programming_Assignment
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SubjectButton = new System.Windows.Forms.Button();
            this.StudentButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // SubjectButton
            // 
            this.SubjectButton.Location = new System.Drawing.Point(67, 120);
            this.SubjectButton.Name = "SubjectButton";
            this.SubjectButton.Size = new System.Drawing.Size(75, 23);
            this.SubjectButton.TabIndex = 3;
            this.SubjectButton.Text = "Subject";
            this.SubjectButton.UseVisualStyleBackColor = true;
            this.SubjectButton.Click += new System.EventHandler(this.SubjectButton_Click);
            // 
            // StudentButton
            // 
            this.StudentButton.Location = new System.Drawing.Point(67, 62);
            this.StudentButton.Name = "StudentButton";
            this.StudentButton.Size = new System.Drawing.Size(75, 23);
            this.StudentButton.TabIndex = 2;
            this.StudentButton.Text = "Student";
            this.StudentButton.UseVisualStyleBackColor = true;
            this.StudentButton.Click += new System.EventHandler(this.StudentButton_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(216, 201);
            this.Controls.Add(this.SubjectButton);
            this.Controls.Add(this.StudentButton);
            this.Name = "Main";
            this.Text = "Main";
            this.Load += new System.EventHandler(this.Main_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button SubjectButton;
        private System.Windows.Forms.Button StudentButton;
    }
}