﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Programming_Assignment
{
    public partial class Student : Form
    {
        OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\User\OneDrive\Desktop\Programming\assignmentdatabase.accdb");
        OleDbCommand cmd = new OleDbCommand();

        public Student()
        {
            InitializeComponent();
        }

        private void Student_Load(object sender, EventArgs e)
        {

        }

        private void Addbutton_Click(object sender, EventArgs e)
        {
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select* from Student where Registration_ID = '" + Regis.Text + "'";
            OleDbDataReader dr = cmd.ExecuteReader();

            if (dr.Read())
            {
                MessageBox.Show("ID already exist!");
                con.Close();

            }
            else
            {

                cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "INSERT INTO Student(Registration_ID, Student_Name, Gender, Intake, Course, Class, Email, Contact_Number, Birthdate, Address, Guardian_Name, Guardian_ContactNumber) VALUES ('" + Regis.Text + "', '" + SName.Text + "','" + Gender.Text + "','" + Intake.Text + "','" + Course.Text + "','" + Class.Text + "','" + Email.Text + "','" + Contact.Text + "','" + Birthdate.Value + "','" + Address.Text + "','" + GName.Text + "','" + GContact.Text + "')";
                cmd.ExecuteNonQuery();
                Regis.Clear();
                SName.Clear();
                Gender.ResetText();
                Intake.Clear();
                Course.ResetText();
                Class.Clear();
                Email.Clear();
                Contact.Clear();
                Birthdate.ResetText();
                Address.Clear();
                GName.Clear();
                GContact.Clear();


                cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select * from Student";
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                dataGridView1.AllowUserToAddRows = false;
                label6.Text = dataGridView1.RowCount.ToString();
                con.Close();
                MessageBox.Show("Successfully add!");
            }
        }

        private void Viewbutton_Click(object sender, EventArgs e)
        {
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Student";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            dataGridView1.AllowUserToAddRows = false;
            label14.Text = dataGridView1.RowCount.ToString();
            con.Close();
        }

        private void Removebutton_Click(object sender, EventArgs e)
        {
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "delete from Student where Registration_ID = '" + Regis.Text + "'";
            cmd.ExecuteNonQuery();

            cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select* from Student";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            dataGridView1.AllowUserToAddRows = false;
            label14.Text = dataGridView1.RowCount.ToString();
            Regis.Clear();
            SName.Clear();
            Gender.ResetText();
            Intake.Clear();
            Course.ResetText();
            Class.Clear();
            Email.Clear();
            Contact.Clear();
            Birthdate.ResetText();
            Address.Clear();
            GName.Clear();
            GContact.Clear();
            con.Close();
            MessageBox.Show("Successfully Delete!");
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            dataGridView1.CurrentRow.Selected = true;


            Regis.Text = dataGridView1.Rows[e.RowIndex].Cells["Registration_ID"].FormattedValue.ToString();
            SName.Text = dataGridView1.Rows[e.RowIndex].Cells["Student_Name"].FormattedValue.ToString();
            Gender.Text = dataGridView1.Rows[e.RowIndex].Cells["Gender"].FormattedValue.ToString();
            Intake.Text = dataGridView1.Rows[e.RowIndex].Cells["Intake"].FormattedValue.ToString();
            Course.Text = dataGridView1.Rows[e.RowIndex].Cells["Course"].FormattedValue.ToString();
            Class.Text = dataGridView1.Rows[e.RowIndex].Cells["Class"].FormattedValue.ToString();
            Email.Text = dataGridView1.Rows[e.RowIndex].Cells["Email"].FormattedValue.ToString();
            Contact.Text = dataGridView1.Rows[e.RowIndex].Cells["Contact_Number"].FormattedValue.ToString();
            Birthdate.Text = dataGridView1.Rows[e.RowIndex].Cells["Birthdate"].FormattedValue.ToString();
            Address.Text = dataGridView1.Rows[e.RowIndex].Cells["Address"].FormattedValue.ToString();
            GName.Text = dataGridView1.Rows[e.RowIndex].Cells["Guardian_Name"].FormattedValue.ToString();
            GContact.Text = dataGridView1.Rows[e.RowIndex].Cells["Guardian_ContactNumber"].FormattedValue.ToString();

        }

        private void Searchbutton_Click(object sender, EventArgs e)
        {
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Student where Registration_ID = '" + Sbutton.Text + "' OR Student_Name = '" + Sbutton.Text + "' ";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void Regis_TextChanged(object sender, EventArgs e)
        {

        }

        private void Editbutton_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                OleDbCommand cmd = new OleDbCommand();
                cmd.Connection = con;
                string query = "update Student set Student_Name = '" + SName.Text + "', Gender = '" + Gender.Text + "', Intake = '" + Intake.Text + "', Course = '" + Course.Text + "', Class= '" + Class.Text + "', Email ='" + Email.Text + "', Contact_Number = '" + Contact.Text + "', Birthdate = '" + Birthdate.Value + "', Address = '" + Address.Text + "', Guardian_Name = '" + GName.Text + "', Guardian_ContactNumber = '" + GContact.Text + "' where Registration_ID = '" + Regis.Text + "'";
                cmd.CommandText = query;
                cmd.ExecuteNonQuery();
                Regis.Clear();
                SName.Clear();
                Gender.ResetText();
                Intake.Clear();
                Course.ResetText();
                Class.Clear();
                Email.Clear();
                Contact.Clear();
                Birthdate.ResetText();
                Address.Clear();
                GName.Clear();
                GContact.Clear();


                cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "Select* from Student";
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                dataGridView1.AllowUserToAddRows = false;
                label6.Text = dataGridView1.RowCount.ToString();
                con.Close();
                MessageBox.Show("Edit Successful!");

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
        }

        private void Menubutton_Click(object sender, EventArgs e)
        {

            Main F2 = new Main();
            F2.Show();
            this.Hide();
        }

        private void Refreshbutton_Click(object sender, EventArgs e)
        {
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select* from Student";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            dataGridView1.AllowUserToAddRows = false;
            label14.Text = dataGridView1.RowCount.ToString();
            con.Close();
        }

        private void Clearbutton_Click(object sender, EventArgs e)
        {
            Regis.Clear();
            SName.Clear();
            Gender.ResetText();
            Intake.Clear();
            Course.ResetText();
            Class.Clear();
            Email.Clear();
            Contact.Clear();
            Birthdate.ResetText();
            Address.Clear();
            GName.Clear();
            GContact.Clear();
            Sbutton.Clear();
            con.Close();

        }
    }
    
}

