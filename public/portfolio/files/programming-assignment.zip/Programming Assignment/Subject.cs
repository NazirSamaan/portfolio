﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;


namespace Programming_Assignment
{
    public partial class SubjectForm : Form
    {
        OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\User\OneDrive\Desktop\Programming\assignmentdatabase.accdb");
        OleDbCommand cmd = new OleDbCommand();

        public SubjectForm()
        {
            InitializeComponent();
        }
        public int click = 0;
        int row;

        private void addbutton_Click(object sender, EventArgs e)
        {
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select* from Subject where ID = '" + SubjectID.Text + "'";
            OleDbDataReader dr = cmd.ExecuteReader();

            if (dr.Read())
            {
                MessageBox.Show("ID already exist!");
                con.Close();

            }
            else
            {
                cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "INSERT INTO Subject(ID, Subject_name, Credit_hour, Description) VALUES ('" + SubjectID.Text + "', '" + Subject.Text + "','" + Credithours.Text + "','" + Description.Text +  "')";
                cmd.ExecuteNonQuery();
                SubjectID.Clear();
                Subject.Clear();
                Credithours.Clear();
                Description.Clear();



                cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select * from Subject";
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                dataGridView1.AllowUserToAddRows = false;
                label2.Text = dataGridView1.RowCount.ToString();
                con.Close();
                MessageBox.Show("Successfully add!");
            }
        }

        private void menubutton_Click(object sender, EventArgs e)
        {
            Main F2 = new Main();
            F2.Show();
            this.Hide();
        }

        private void viewbutton_Click(object sender, EventArgs e)
        {
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Subject";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            dataGridView1.AllowUserToAddRows = false;
            label2.Text = dataGridView1.RowCount.ToString();
            con.Close();
        }

        private void removebutton_Click(object sender, EventArgs e)
        {
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "delete from Subject where ID = '" + SubjectID.Text + "'";
            cmd.ExecuteNonQuery();

            cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select* from Subject";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            dataGridView1.AllowUserToAddRows = false;
            label2.Text = dataGridView1.RowCount.ToString();
            SubjectID.Clear();
            Subject.Clear();
            Credithours.Clear();
            Description.Clear();
            con.Close();
            MessageBox.Show("Successfully Delete!");
        }

        private void editbutton_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                OleDbCommand cmd = new OleDbCommand();
                cmd.Connection = con;
                string query = "update Subject set Subject_name = '" + Subject.Text + "', Credit_hour = '" + Credithours.Text + "', Description = '" + Description.Text + "' where ID = '" + SubjectID.Text + "'";
                cmd.CommandText = query;
                cmd.ExecuteNonQuery();
                SubjectID.Clear();
                Subject.Clear();
                Credithours.Clear();
                Description.Clear();


                cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "Select* from Subject";
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                dataGridView1.AllowUserToAddRows = false;
                label2.Text = dataGridView1.RowCount.ToString();
                con.Close();
                MessageBox.Show("Edit Successful!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
        }

        private void previousbutton_Click(object sender, EventArgs e)
        {
            if (row >= 0)
            {
                if (row != 0)
                {
                    dataGridView1.Rows[row].Selected = false;
                    dataGridView1.Rows[--row].Selected = true;

                    SubjectID.Text = dataGridView1.Rows[row].Cells["ID"].FormattedValue.ToString();
                    Subject.Text = dataGridView1.Rows[row].Cells["Subject_name"].FormattedValue.ToString();
                    Credithours.Text = dataGridView1.Rows[row].Cells["Credit_hour"].FormattedValue.ToString();
                    Description.Text = dataGridView1.Rows[row].Cells["Description"].FormattedValue.ToString();
                }
                else
                {
                    MessageBox.Show("Already to the First Record");
                }
            }
        }

        private void nextbutton_Click(object sender, EventArgs e)
        {
            if (row < dataGridView1.RowCount)
            {
                if (row < dataGridView1.RowCount - 1)
                {
                    dataGridView1.Rows[row].Selected = false;
                    dataGridView1.Rows[++row].Selected = true;

                    SubjectID.Text = dataGridView1.Rows[row].Cells["ID"].FormattedValue.ToString();
                    Subject.Text = dataGridView1.Rows[row].Cells["Subject_name"].FormattedValue.ToString();
                    Credithours.Text = dataGridView1.Rows[row].Cells["Credit_hour"].FormattedValue.ToString();
                    Description.Text = dataGridView1.Rows[row].Cells["Description"].FormattedValue.ToString();
                }
                else
                {
                    MessageBox.Show("Already to the last Record");
                }
            }
        }
        private void refreshbutton_Click(object sender, EventArgs e)
        {
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select* from Subject";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            dataGridView1.AllowUserToAddRows = false;
            label2.Text = dataGridView1.RowCount.ToString();
            con.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.SelectedRows.Count != -1)
            {
                click = 1;
                {
                    row = dataGridView1.CurrentRow.Index;
                    SubjectID.Text = dataGridView1.Rows[e.RowIndex].Cells["ID"].FormattedValue.ToString();
                    Subject.Text = dataGridView1.Rows[e.RowIndex].Cells["Subject_name"].FormattedValue.ToString();
                    Credithours.Text = dataGridView1.Rows[e.RowIndex].Cells["Credit_hour"].FormattedValue.ToString();
                    Description.Text = dataGridView1.Rows[e.RowIndex].Cells["Description"].FormattedValue.ToString();
                }
            }
        }

    }
}
