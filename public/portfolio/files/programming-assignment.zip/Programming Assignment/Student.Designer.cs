﻿namespace Programming_Assignment
{
    partial class Student
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Regis = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.SName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Intake = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.Class = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.Email = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.Contact = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.Address = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.GName = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Refreshbutton = new System.Windows.Forms.Button();
            this.Editbutton = new System.Windows.Forms.Button();
            this.Viewbutton = new System.Windows.Forms.Button();
            this.Birthdate = new System.Windows.Forms.DateTimePicker();
            this.Clearbutton = new System.Windows.Forms.Button();
            this.Removebutton = new System.Windows.Forms.Button();
            this.Addbutton = new System.Windows.Forms.Button();
            this.Searchbutton = new System.Windows.Forms.Button();
            this.Menubutton = new System.Windows.Forms.Button();
            this.Sbutton = new System.Windows.Forms.TextBox();
            this.Course = new System.Windows.Forms.ComboBox();
            this.Gender = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.GContact = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(16, 33);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1368, 195);
            this.dataGridView1.TabIndex = 67;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // Regis
            // 
            this.Regis.Location = new System.Drawing.Point(98, 282);
            this.Regis.Name = "Regis";
            this.Regis.Size = new System.Drawing.Size(162, 20);
            this.Regis.TabIndex = 43;
            this.Regis.TextChanged += new System.EventHandler(this.Regis_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 318);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 13);
            this.label2.TabIndex = 44;
            this.label2.Text = "Student Name";
            // 
            // SName
            // 
            this.SName.Location = new System.Drawing.Point(98, 316);
            this.SName.Name = "SName";
            this.SName.Size = new System.Drawing.Size(162, 20);
            this.SName.TabIndex = 45;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(40, 347);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 13);
            this.label3.TabIndex = 46;
            this.label3.Text = "Gender";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(51, 378);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 13);
            this.label4.TabIndex = 47;
            this.label4.Text = "Intake";
            // 
            // Intake
            // 
            this.Intake.Location = new System.Drawing.Point(98, 375);
            this.Intake.Name = "Intake";
            this.Intake.Size = new System.Drawing.Size(162, 20);
            this.Intake.TabIndex = 48;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(319, 286);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(40, 13);
            this.label5.TabIndex = 49;
            this.label5.Text = "Course";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(325, 319);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(32, 13);
            this.label6.TabIndex = 50;
            this.label6.Text = "Class";
            // 
            // Class
            // 
            this.Class.Location = new System.Drawing.Point(363, 316);
            this.Class.Name = "Class";
            this.Class.Size = new System.Drawing.Size(133, 20);
            this.Class.TabIndex = 51;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(325, 347);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(32, 13);
            this.label7.TabIndex = 52;
            this.label7.Text = "Email";
            // 
            // Email
            // 
            this.Email.Location = new System.Drawing.Point(362, 344);
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(134, 20);
            this.Email.TabIndex = 53;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(273, 377);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(84, 13);
            this.label8.TabIndex = 54;
            this.label8.Text = "Contact Number";
            // 
            // Contact
            // 
            this.Contact.Location = new System.Drawing.Point(362, 375);
            this.Contact.Name = "Contact";
            this.Contact.Size = new System.Drawing.Size(133, 20);
            this.Contact.TabIndex = 55;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(35, 407);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(52, 13);
            this.label9.TabIndex = 56;
            this.label9.Text = "Birth date";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(540, 285);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(45, 13);
            this.label10.TabIndex = 57;
            this.label10.Text = "Address";
            // 
            // Address
            // 
            this.Address.Location = new System.Drawing.Point(591, 282);
            this.Address.Name = "Address";
            this.Address.Size = new System.Drawing.Size(180, 20);
            this.Address.TabIndex = 58;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(507, 318);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(81, 13);
            this.label11.TabIndex = 59;
            this.label11.Text = "Guardian Name";
            // 
            // GName
            // 
            this.GName.Location = new System.Drawing.Point(591, 315);
            this.GName.Name = "GName";
            this.GName.Size = new System.Drawing.Size(180, 20);
            this.GName.TabIndex = 60;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(501, 347);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(84, 13);
            this.label12.TabIndex = 61;
            this.label12.Text = "Contact Number";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 285);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 13);
            this.label1.TabIndex = 63;
            this.label1.Text = "Registration ID";
            // 
            // Refreshbutton
            // 
            this.Refreshbutton.Location = new System.Drawing.Point(16, 236);
            this.Refreshbutton.Name = "Refreshbutton";
            this.Refreshbutton.Size = new System.Drawing.Size(75, 23);
            this.Refreshbutton.TabIndex = 64;
            this.Refreshbutton.Text = "Refresh";
            this.Refreshbutton.UseVisualStyleBackColor = true;
            this.Refreshbutton.Click += new System.EventHandler(this.Refreshbutton_Click);
            // 
            // Editbutton
            // 
            this.Editbutton.Location = new System.Drawing.Point(259, 235);
            this.Editbutton.Name = "Editbutton";
            this.Editbutton.Size = new System.Drawing.Size(75, 23);
            this.Editbutton.TabIndex = 65;
            this.Editbutton.Text = "Edit";
            this.Editbutton.UseVisualStyleBackColor = true;
            this.Editbutton.Click += new System.EventHandler(this.Editbutton_Click);
            // 
            // Viewbutton
            // 
            this.Viewbutton.Location = new System.Drawing.Point(97, 235);
            this.Viewbutton.Name = "Viewbutton";
            this.Viewbutton.Size = new System.Drawing.Size(75, 23);
            this.Viewbutton.TabIndex = 66;
            this.Viewbutton.Text = "View";
            this.Viewbutton.UseVisualStyleBackColor = true;
            this.Viewbutton.Click += new System.EventHandler(this.Viewbutton_Click);
            // 
            // Birthdate
            // 
            this.Birthdate.Location = new System.Drawing.Point(97, 404);
            this.Birthdate.Name = "Birthdate";
            this.Birthdate.Size = new System.Drawing.Size(207, 20);
            this.Birthdate.TabIndex = 68;
            // 
            // Clearbutton
            // 
            this.Clearbutton.Location = new System.Drawing.Point(421, 235);
            this.Clearbutton.Name = "Clearbutton";
            this.Clearbutton.Size = new System.Drawing.Size(75, 23);
            this.Clearbutton.TabIndex = 69;
            this.Clearbutton.Text = "Clear";
            this.Clearbutton.UseVisualStyleBackColor = true;
            this.Clearbutton.Click += new System.EventHandler(this.Clearbutton_Click);
            // 
            // Removebutton
            // 
            this.Removebutton.Location = new System.Drawing.Point(340, 235);
            this.Removebutton.Name = "Removebutton";
            this.Removebutton.Size = new System.Drawing.Size(75, 23);
            this.Removebutton.TabIndex = 70;
            this.Removebutton.Text = "Remove";
            this.Removebutton.UseVisualStyleBackColor = true;
            this.Removebutton.Click += new System.EventHandler(this.Removebutton_Click);
            // 
            // Addbutton
            // 
            this.Addbutton.Location = new System.Drawing.Point(178, 235);
            this.Addbutton.Name = "Addbutton";
            this.Addbutton.Size = new System.Drawing.Size(75, 23);
            this.Addbutton.TabIndex = 71;
            this.Addbutton.Text = "Add";
            this.Addbutton.UseVisualStyleBackColor = true;
            this.Addbutton.Click += new System.EventHandler(this.Addbutton_Click);
            // 
            // Searchbutton
            // 
            this.Searchbutton.Location = new System.Drawing.Point(567, 4);
            this.Searchbutton.Name = "Searchbutton";
            this.Searchbutton.Size = new System.Drawing.Size(75, 23);
            this.Searchbutton.TabIndex = 72;
            this.Searchbutton.Text = "Search";
            this.Searchbutton.UseVisualStyleBackColor = true;
            this.Searchbutton.Click += new System.EventHandler(this.Searchbutton_Click);
            // 
            // Menubutton
            // 
            this.Menubutton.Location = new System.Drawing.Point(16, 4);
            this.Menubutton.Name = "Menubutton";
            this.Menubutton.Size = new System.Drawing.Size(75, 23);
            this.Menubutton.TabIndex = 73;
            this.Menubutton.Text = "Menu";
            this.Menubutton.UseVisualStyleBackColor = true;
            this.Menubutton.Click += new System.EventHandler(this.Menubutton_Click);
            // 
            // Sbutton
            // 
            this.Sbutton.Location = new System.Drawing.Point(657, 6);
            this.Sbutton.Name = "Sbutton";
            this.Sbutton.Size = new System.Drawing.Size(114, 20);
            this.Sbutton.TabIndex = 74;
            // 
            // Course
            // 
            this.Course.FormattingEnabled = true;
            this.Course.Items.AddRange(new object[] {
            "SQA",
            "BTEC",
            "NCC"});
            this.Course.Location = new System.Drawing.Point(362, 282);
            this.Course.Name = "Course";
            this.Course.Size = new System.Drawing.Size(133, 21);
            this.Course.TabIndex = 75;
            // 
            // Gender
            // 
            this.Gender.FormattingEnabled = true;
            this.Gender.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.Gender.Location = new System.Drawing.Point(98, 343);
            this.Gender.Name = "Gender";
            this.Gender.Size = new System.Drawing.Size(162, 21);
            this.Gender.TabIndex = 76;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(690, 239);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(34, 13);
            this.label13.TabIndex = 77;
            this.label13.Text = "Total:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(752, 240);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(19, 13);
            this.label14.TabIndex = 78;
            this.label14.Text = "00";
            // 
            // GContact
            // 
            this.GContact.Location = new System.Drawing.Point(591, 340);
            this.GContact.Name = "GContact";
            this.GContact.Size = new System.Drawing.Size(180, 20);
            this.GContact.TabIndex = 79;
            // 
            // Student
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1431, 438);
            this.Controls.Add(this.GContact);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.Gender);
            this.Controls.Add(this.Course);
            this.Controls.Add(this.Sbutton);
            this.Controls.Add(this.Menubutton);
            this.Controls.Add(this.Searchbutton);
            this.Controls.Add(this.Addbutton);
            this.Controls.Add(this.Removebutton);
            this.Controls.Add(this.Clearbutton);
            this.Controls.Add(this.Birthdate);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.Viewbutton);
            this.Controls.Add(this.Editbutton);
            this.Controls.Add(this.Refreshbutton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.GName);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.Address);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.Contact);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.Email);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.Class);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Intake);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.SName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Regis);
            this.Name = "Student";
            this.Text = "Student";
            this.Load += new System.EventHandler(this.Student_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox Regis;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox SName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox Intake;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox Class;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox Email;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox Contact;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox Address;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox GName;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Refreshbutton;
        private System.Windows.Forms.Button Editbutton;
        private System.Windows.Forms.Button Viewbutton;
        private System.Windows.Forms.DateTimePicker Birthdate;
        private System.Windows.Forms.Button Clearbutton;
        private System.Windows.Forms.Button Removebutton;
        private System.Windows.Forms.Button Addbutton;
        private System.Windows.Forms.Button Searchbutton;
        private System.Windows.Forms.Button Menubutton;
        private System.Windows.Forms.TextBox Sbutton;
        private System.Windows.Forms.ComboBox Course;
        private System.Windows.Forms.ComboBox Gender;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox GContact;
    }
}