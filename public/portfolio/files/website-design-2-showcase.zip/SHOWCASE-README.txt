Bright Master College website showcase

Includes the original HTML pages, CSS, JavaScript, images, and fonts.
Open Website Design 2/home.html to view the site.
Large original video assets are omitted from this showcase download.
